let canvas = document.querySelector('.fireworks'),
    ctx = canvas.getContext('2d'),

    //Fullscreen dimensions
    canvasWidth = window.innerWidth,
    canvasHeight = window.innerHeight,

    //Particle Object Array
    fireworks = [],
    boomBooms = [],
    smokePuffs = [],

    maxSmokeVelocity = 1,
    hue = 120,

    //When launching fireworks via a click, too many
    //particles will be emitted at once without some
    //limitation applied. So, we'll use the following
    //variables to limit to one launch per 5 loop ticks

    limiterTotal = 5,
    limiterTick = 0,

    //We also need to time auto launches of fireworks
    //particles to see one launch every 80 loop ticks

    timerTotal = 80,
    timerTick = 0,

    mouseDown = false,
    mouseXPosition,
    mouseYPosition,

    smokeImage = new Image(); //Same as creating an empty <img> tag in HTML

    //Preload the smoke image
    smokeImage.src = 'images/smoke.png';

    //Match our canvas tag to the browser's inner window dimensions.
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    //Helper Functions
    //Random number generator
    function randRange (min, max){

      return Math.random() * (max - min) + min;

    }

    //Calculate the distance between two points
    function calculateDistance(point1X, point1Y, point2X, point2Y){

      return Math.sqrt(Math.pow(point2X - point1X, 2) + Math.pow(point2Y - point1Y, 2))

    }

    //Create a Firework particle object class constructor
    function Firework(startX, startY, targetX, targetY){

      //Remember that the this keyword when used in the context of a constructor
      //function or the class's method definitions, references the newly constructed object
      this.x = startX;
      this.y = startY;

      this.startX = startX;
      this.startY = startY;

      this.targetX = targetX;
      this.targetY = targetY;

      //Distance between the starting an target points
      this.distanceToTarget = calculateDistance(startX, startY, targetX, targetY);

      this.distanceTravelled = 0;

      //Track the coordinates of where the Firework particle has been
      //as it is flying towards the target point so we can create a 
      //trail effect
      this.coordinates = [];

      //Randomly select amount of coordinates to save
      this.coordinateCount = Math.floor(randRange(1, 7));

      //Populate the initial coordinates array with the current coordinates of the particel
      while (this.coordinateCount--){
        this.coordinates.push([this.x, this.y])
      }

      this.angle = Math.atan2(targetY - startY, targetX - startX);

      this.speed = 2;

      this.acceleration =  1.05;

      this.brightness = randRange(50, 70);

      //circle target indicator (radius)
      this.targetRadius = 1;

    }

    //Create methods for our Firework class using the prototype property
    Firework.prototype.draw = function(){
      ctx.beginPath();

      //Move to the last tracked coordinate (last element) in our coordinates array property.
      //This will be the starting point of the line we will draw.
      ctx.moveTo(this.coordinates[this.coordinates.length - 1][0], this.coordinates[this.coordinates.length - 1][1]);

      //Specify the ending point of the line to be drawn
      ctx.lineTo(this.x, this.y);

      ctx.strokeStyle = 'hsl('+hue+', 100%, '+this.brightness+'%)';

      //Draw the line
      ctx.stroke();

      //At this point, we won't see anything yet until we draw the target circle.
      //Draw a circle to represent the firework's target
      ctx.beginPath();
      ctx.arc(this.targetX, this.targetY, this.targetRadius, 0, Math.PI * 2);
      ctx.stroke();

    }

    Firework.prototype.update = function(index){
      //Remove the last element from the coordinates array property
      this.coordinates.pop();

      //Add the point the Firework particle is now at to the beginning
      //of the coordinates array property
      this.coordinates.unshift([this.x, this.y]);

      //Make the target circle pulsate by adjusting it's radius
      if(this.targetRadius < 8){
        this.targetRadius += .3;
      } else {
        this.targetRadius = 1;
      }

      //Speed up the firework
      this.speed *= this.acceleration;

      //Calculate the current velocities based on angle and speed
      //
      //  cosine = adjacent/hypotenuse sine = opposite/hypotenuse
      let velocityX = Math.cos(this.angle) * this.speed,
          velocityY = Math.sin(this.angle) * this.speed;

      //How far will the Firework object have travelled with the
      //above velocities applied?
      this.distanceTravelled = calculateDistance(this.startX, this.startY, this.x + velocityX, this.y + velocityY);

      //If the distance travelled including velocities, is greater than
      //the initial distance to the target, then the target has been reached.
      if(this.distanceTravelled >= this.distanceToTarget){

        //Firework has arrived at target - BOOM!
        createExplosion(this.targetX, this.targetY);

        //Create smoke
        createSmoke(this.targetX, this.targetY);

        //TODO
        //Clean up - remove the firework particle object from the fireworks array
        fireworks.splice(index, 1)

      } else { //Not at target yet, keep going!
        this.x += velocityX;
        this.y += velocityY;
      }

    }

    //Create explosion particles
    function createExplosion(x, y){

      let particlesCount = 90;

      while (particlesCount--){
        boomBooms.push(new ExplosionParticle(x, y));
      }

    }

    //ExplosionParticle class (ES6 syntax)
    class ExplosionParticle{

      constructor(x, y){

        //Saving parameter variables for later use
        this.x = x;
        this.y = y;

        this.coordinates = [];
        this.coordinateCount = Math.round(randRange(10,20));

        while(this.coordinateCount--){
          this.coordinates.push([this.x, this.y]);
        }

        this.angle = randRange(0, Math.PI *2);
        this.speed = randRange(1, 10);

        this.friction = .95;
        this.gravity = 1;

        this.hue = randRange(hue - 20, hue + 20);
        this.brightness = randRange(50, 80);

        this.alpha = 1;
        this.decay = randRange(.003, .006);

      }

      //Create two instance methods for this class named draw and update
      draw = function(){

        ctx.beginPath();
        
        //Move to the last tracked coordinate(last element in coordinates[])
        //this will be the starting point of the line we'll draw
        ctx.moveTo(this.coordinates[this.coordinates.length - 1][0], this.coordinates[this.coordinates.length - 1][1]);

        //Now draw the curve of the explosion
        ctx.quadraticCurveTo(this.x + 1, this.y - Math.random(randRange(5, 10)), this.x, this.y);

        ctx.strokeStyle = `hsla(${this.hue}, 100%, ${this.brightness}%, ${this.alpha})`;

        //Draw the curve
        ctx.stroke();

      }

      update = function(index){

        //Remove the last element from the coordinates array
        this.coordinates.pop();

        //Add the point the Explosion particle is now at to the beginning
        //of the coordinates array property
        this.coordinates.unshift([this.x, this.y]);

        //Slow down the descent of the explosion particle
        this.speed *= this.friction;

        //Update position
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed + this.gravity;

        //Fade out Explosion properties
        this.alpha -= this.decay;

        //Clean up explosion particle
        if(this.alpha <= this.decay){
          boomBooms.splice(index, 1);
        }

      }

    }

    function createSmoke(x, y){

      let puffCount = 1;

      for(let i = 0; i < puffCount; i++){
        smokePuffs.push(new SmokePuff(x, y));
      }

    }
    class SmokePuff{

      constructor(x, y){
        this.x = randRange(x - 25, x + 25);
        this.y = randRange(y - 15, y + 15);

        this.xVelocity = randRange(.2, maxSmokeVelocity);
        this.yVelocity = randRange(-.1, -maxSmokeVelocity);

        this.alpha = .4;
      }

      draw = function(){
        ctx.save();

        ctx.globalAlpha = this.alpha;

        ctx.drawImage(smokeImage, this.x - smokeImage.width/2, this.y - smokeImage.height/2);

        ctx.restore();
      }

      update = function(index){
        
        this.x += this.xVelocity;
        this.y += this.yVelocity;

        this.alpha -= .001;

        if(this.alpha <= 0){
          smokePuffs.splice(index, 1);
        }

      }

    }


    //heartBeat will be executed framerate times per second (60) as an infinite loop
    function heartBeat(){

      //Call heartBeat recursively framerate times per second
      requestAnimationFrame(heartBeat);

      //Increase the hue value slightly to get different
      //firework colors over time
      hue = (hue + .5) % 240;

      //Normally, we'd use the ctx.clearRect() method to clear the entire canvas
      //or just a smaller rectangular portion of it. But we want to create a trail
      //effect on our firework as it travels through the "sky". 
      //
      //Setting the composition operation of the context object to a value of
      //'destination-out' will allow us to clear the canvas at a specific opacity
      //rather than wiping it completely clear. 
      ctx.globalCompositeOperation = 'destination-out';

      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      //Resetting the composite operation value of 'lighter' creates bright
      //highlight points as the fireworks and the explosion particles overlap 
      //each other. 
      ctx.globalCompositeOperation = 'lighter';

      //Loop over each Firework particle, draw it, and animate it
      let i = fireworks.length;

      while(i--){
        fireworks[i].draw();
        fireworks[i].update(i);
      }

      let j = boomBooms.length;

      while(j--){
        boomBooms[j].draw();
        boomBooms[j].update(j);
      }

      let k = smokePuffs.length;

      while(k--){
        smokePuffs[k].draw();
        smokePuffs[k].update(k);
      }

      //Launch a firework automatically to a random target coordinate
      //when the mouse is not pressed down... 
      if(timerTick >= timerTotal){
        if(!mouseDown){ //Autolaunch firework
          //Launch a firework particle from the bottom center of the screen
          //then set a random target coordinate. The target's Y-position
          //should always be in the top half of the screen.
          fireworks.push(new Firework(canvasWidth/2, canvasHeight, randRange(0, canvasWidth), randRange(0, canvasHeight/2)));

          timerTick = 0;

        }
      } else {

        timerTick++;

      }

      //Launch a firework in response to a click
      if(limiterTick >= limiterTotal){

        if(mouseDown){ //launch firework

          //Launch a firework particle from the bottom center of the screen
          //to the clicked coordinate
          fireworks.push(new Firework(canvasWidth/2, canvasHeight, mouseXPosition, mouseYPosition));

          limiterTick = 0;

        }
      } else {

        limiterTick++;

      }

    }

    //Event Listeners
    canvas.addEventListener('mousedown', function(e){
      mouseDown = true;
      e.preventDefault();
    })

    canvas.addEventListener('mouseup', function(e){
      mouseDown = false;
      e.preventDefault();
    })

    canvas.addEventListener('mousemove', function(e){
      mouseXPosition = e.offsetX;
      mouseYPosition = e.offsetY;
    })

    //Start heartBeat on load
    window.onload = heartBeat;
